﻿namespace Restaurant.WebApp.Models
{
    public class CartItemViewModel
    {
        public int Id { get; set; }
        public string ProductName { get; set; }
        public decimal? Price { get; set; }
        public int Quantity { get; set; }
        public decimal? Total => Price * Quantity;
    }
}
